# 京伸 リンクページ (kyoshin-link-site)

株式会社京伸の Instagram 用リンクまとめページ。単一の index.html で動く静的サイト。

## GitHub Pages での公開
1. GitHub に新しいリポジトリを作る(例: kyoshin-link)
2. このフォルダの中身をすべてアップロード(index.html / .nojekyll など)
3. リポジトリの Settings → Pages → Branch を main / (root) にして Save
4. 数分後 https://<ユーザー名>.github.io/<リポジトリ名>/ で公開される
5. その URL を Instagram プロフィールのリンク欄に貼る

詳しい仕様・調整メモは CLAUDE.md を参照。
